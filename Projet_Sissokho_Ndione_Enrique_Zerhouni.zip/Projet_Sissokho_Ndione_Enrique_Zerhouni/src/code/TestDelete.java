package code;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;

public class TestDelete {
	
	public static void main(String args[]) 
	{
		ArrayList<String> typecolonne=new ArrayList<>();
		typecolonne.add("int");
		typecolonne.add("string3");
		typecolonne.add("int");
		RelDef rf=new RelDef("ndione", 3 ,typecolonne);
		Record rd= new Record(rf);
		rd.addValue("1");
		rd.addValue("abc");
		rd.addValue("7");
		/*rd.addValue("2");
		rd.addValue("xhs");
		rd.addValue("6");
		rd.addValue("5");
		rd.addValue("acb");
		rd.addValue("4"); */
		byte []buff=new byte[40];
		//ByteBuffer b=ByteBuffer.wrap(buff);
		rd.writeToBuffer(buff, 0);
		
		System.out.println(Arrays.toString(buff));
	}

}
