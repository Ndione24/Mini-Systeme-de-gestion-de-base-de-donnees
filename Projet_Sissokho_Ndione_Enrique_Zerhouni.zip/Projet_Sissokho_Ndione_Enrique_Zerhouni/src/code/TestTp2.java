package code;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class TestTp2 {

	public static void main(String[] args) throws IOException {

		byte[] buffer = new byte[20];
		ByteBuffer headerPage = ByteBuffer.wrap(buffer);
		int nPage = headerPage.getInt();
		buffer[3]++;
		headerPage.putInt(120);
		headerPage.putInt(3);

		System.out.println(Arrays.toString(buffer));
		// pour recuperer la deuxieme int qui correspond � slotCount de la premiere Page
		System.out.println(headerPage.getInt(4));
		// pour decrementer le slotCount de la premiere page
		buffer[7]--;
		System.out.println(Arrays.toString(buffer));
		// System.out.println(headerPage.getInt(4));

		// test page dispo
		byte[] page = new byte[30];
		ByteBuffer b = ByteBuffer.wrap(page);
		b.putInt(5);
		b.putInt(1);
		b.putInt(0);
		b.putInt(3);
		b.putInt(0);
		b.putInt(1);
		System.out.println("non");
		int nbPages = b.getInt(0);
		System.out.println(nbPages);
		System.out.println(Arrays.toString(page));
		for (int i = 4; i <= 4*nbPages; i = i + 4) {
			if (b.getInt(i) != 0 && b.getInt(i) > 0 && b.getInt(i) <= 5) {
				System.out.println("page dispo " + i / 4);

			}
			else 
			{
				System.out.println("non");
			}

		}
	}
}