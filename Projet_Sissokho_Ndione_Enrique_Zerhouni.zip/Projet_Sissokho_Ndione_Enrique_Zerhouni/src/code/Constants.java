package code;

public class Constants {
	
	  //la taille d'un page
	public static final int PAGESIZE =4096;
	  //nombre de case =2
	public static final int FRAMECOUNT=2;
	public static final int TAILLEBUFFER=4096;

	//chemin abslolue � supprimer
	public static String CHEMINDB="src\\DB\\";
	
	public static String CHEMINFILE="src\\DB\\Data_";
	public static String CHEMINRACINE="src\\";
	
}