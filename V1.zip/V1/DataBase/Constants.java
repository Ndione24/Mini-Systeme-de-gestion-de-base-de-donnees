package DataBase;

public class Constants {
	
	  //la taille d'un page
	public static final int PAGESIZE =4096;
	  //nombre de case =2
	public static final int FRAMECOUNT=2;
	public static final int TAILLEBUFFER=4096;

	public static String CHEMINDB="C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB";
	
	public static String CHEMINFILE="C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\Data_";
	public static String CHEMINRACINE="C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\";
	
	
}
