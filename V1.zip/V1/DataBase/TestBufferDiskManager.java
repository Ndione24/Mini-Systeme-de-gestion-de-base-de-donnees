/*************************************************************************
 *                                                                       *
 * 					Test BufferManager et DisKmanager					 *

 * 
 *************************************************************************/


package DataBase;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class TestBufferDiskManager {
	
	public static void main(String [] args) 
	{
		
		
		BufferManager2 bm= BufferManager2.getInstance();
		DiskManager dm =DiskManager.getInstance();
		
		System.out.println("Creation de fichier");
		
		dm.createFile(7);
		
		try {
			/*
			PageId firstPage= dm.addPage(7);
			PageId twPage= dm.addPage(7);
			PageId thPage= dm.addPage(7); 
			*/
			
			PageId firstPage= new PageId(7,0);
			PageId page3=new PageId(7,2);
			
			PageId page2=new PageId(7,1); 
			
			
			System.out.println("Nombre De page ajout� dans le fichier d'indice 7");
			dm.displayNumberPage(7);
			
			System.out.println("Ecriture sur la page 1 du fichier d'indice 7 ");
			byte bufWrite[]=new byte[Constants.TAILLEBUFFER];
			byte buffRead[]=new byte[Constants.TAILLEBUFFER];
			byte [] buffWritep2=new byte[Constants.TAILLEBUFFER];
			/*for(byte i=0;i<10;i++) 
			{
				bufWrite[i]=(byte)(i+1);
			}
			dm.writePage(firstPage, bufWrite);
			
			for(byte i=0;i<10;i++) 
			{
				buffWritep2[i]=(byte) (2*(i+1));
			}
			
			dm.writePage(thPage,buffWritep2);*/
			
			dm.readPage(firstPage, buffRead);
			
			System.out.println("Ce qu'on a lu");
			System.out.println(Arrays.toString(buffRead));
			
			byte [] retour;
			byte []retour2;
			byte []retour3;
			retour=bm.getPage(firstPage);
			
			retour2=bm.getPage(page3);
			retour2=bm.getPage(page3);
			retour2=bm.getPage(page3);
			
			
			
			//tester les equals de pageId avant d'avancer
			//le get fonctionne
			//essayons de faire un free en modifiant la valeur donne par get	
			//getPage doit remplir le buffer de la frame avec le buffer associ� � la page
			System.out.println("Apres getPage 1");
			System.out.println(Arrays.toString(retour));
			
			System.out.println("Apres getPage 2");
			System.out.println(Arrays.toString(retour2)); 
			
			bm.infoFrameBufferpool();
			
		/*	retour[0]=10;
			retour[1]=10;  */
			
			//free
		/*	System.out.println("Apres Free sur 1");
			bm.freePage(firstPage, 1);
			
			bm.infoFrameBufferpool();
			System.out.println("Apres getPage 2: LRU");
			retour3=bm.getPage(page2);
			System.out.println(Arrays.toString(retour3)); 
			
			bm.infoFrameBufferpool(); */
			
			
			
			//Ecriture via bufferManager
			byte bufff[] = new byte[Constants.TAILLEBUFFER];
			for(int i=1;i<=10;i++) 
			{
				bufff[i-1]=(byte)(3*(i));
			}
			
			System.out.println("Apres ecriture sur 2");
			
			byte re[]=bm.getPage(page3);
			//re[0]=7;
			ByteBuffer bbuffer= ByteBuffer.wrap(re);
			System.out.println(Arrays.toString(re));
			bm.infoFrameBufferpool();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}