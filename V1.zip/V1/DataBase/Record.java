package DataBase;
import java.util.List;
import java.util.StringTokenizer;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;

public class Record {

	private RelDef relDef;

	private List<String> values;

	List<String> typesValues = new ArrayList<String>();

	public Record(RelDef relDef, List<String> values) {
		this.values = values;
		this.relDef = relDef;

	}

	/**
	 * 2�me constructeur qui initialise les attributs en fonction des variables
	 * pass�s en param�tre
	 */

	/**
	 * constructeur qui prend en parametre une reldef
	 */

	public Record(RelDef relDef){
		this.relDef = relDef;
		// values aura comme taille le nombre de colonne de la relation
		this.values = new ArrayList<String>(relDef.getNbColonnes());
		List<String> typeColonne = relDef.getTypesColonnes();

		for (String s : typeColonne) {
			typesValues.add(s);
		}

	}

	/**
	 * Les gettters et setters necessaires
	 */
	public RelDef getRelDef() {
		return this.relDef;
	}

	public void setRelDef(RelDef relDef) {
		this.relDef = relDef;
	}

	public List<String> getValues() {
		return this.values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	/**
	 * methode qui devra �crire les valeurs du Record dans le buffer, l�une apr�s
	 * l�autre, � partir de position.
	 */

	public void writeToBuffer(byte[] buf, int position) {

		// la taille de values est egale � nombreColonne

		typesValues = relDef.getTypesColonnes();
		int nbColonne = relDef.getNbColonnes();
		// System.exit(0);
		ByteBuffer buff = ByteBuffer.wrap(buf);

		// on met la position du curseur � la position " position " donn�e
		buff.position(position);

		for (int e = 0; e < this.values.size(); e = e + nbColonne) {

			for (int i = 0; i < nbColonne; i++) {
				if (typesValues.get(i).equals("int")) {

					int interm = Integer.parseInt(values.get(i + e));
					System.out.println("I" + i);
					buff.putInt(interm);
				}

				// On verifie si c'est un float
				else if (typesValues.get(i).equals("float")) {
					// variable intermediaire pour convertir le type
					// avant de le mettre dans le buffer
					float inter = Float.parseFloat(values.get(i + e));
					System.out.println("f" + i);
					buff.putFloat(inter);
				}

				// On verifie si c'est un double
				else if (typesValues.get(i).startsWith("string")) {
					// variable intermediaire pour convertir le type
					// avant de le mettre dans le buffer

					String reste = typesValues.get(i).replace("string", "").trim();

					StringBuilder sb = new StringBuilder();
					sb.append(values.get(i + e));

					int lenght = Integer.parseInt(reste);
					for (int j = 0; j < lenght; j++) {
						buff.putChar(sb.charAt(j));
					}

				}

				else {
					System.out.println("hein");
				}

			} // fin boucle for

		}
	}

	/**
	 * cette methode devra lire les valeurs du Record depuis le buffer, l�une apr�s
	 * l�autre, � partir de position.
	 */

	// rempli les valeurs du records depuis le buffer
	public void readFromBuffer(ByteBuffer buff, int position){

		
		//ByteBuffer buff=ByteBuffer.wrap(buf);
		int nbColonne = relDef.getNbColonnes();
		buff.position(position);
		/*System.out.println(buff.getInt());
		//System.out.println(buff.getInt());
		System.out.println(buff.getChar());
		System.out.println(buff.getChar());
		System.out.println(buff.getChar());
		System.out.println(buff.getInt()); */
		System.out.println(buff.capacity());
		System.out.println(buff.position());
		int val;
		Float valF;
//for(int s=0;s<6/nbColonne;s++){}
		for (int i = 0; i < nbColonne; i++) {
			if (typesValues.get(i).equals("int")){
				//conversion
				 val=buff.getInt();
				this.values.add(Integer.toString(val));
			}

			// On verifie si c'est un float
			else if (typesValues.get(i).equals("float")) {
				valF=buff.getFloat();
				this.values.add(Float.toString(valF));
				
			}

			// On verifie si c'est un double
			else if (typesValues.get(i).startsWith("string")) {
				// variable intermediaire pour convertir le type
				// avant de le mettre dans le buffer

				String reste = typesValues.get(i).replace("string", "").trim();

				StringBuilder sb = new StringBuilder();

				int lenght = Integer.parseInt(reste);
				for (int j = 0; j < lenght; j++) {
					sb.append(buff.getChar());
					
				}
				this.values.add(sb.toString());

			}

			else {
				System.out.println("hein");
			}

		} // fin boucle for

	}
	
	public void addValue(String t)
	{
		this.values.add(t);
	}
	
	public void dispalayValue()
	{
		for(String t: this.values) 
		{
			System.out.println(t);
		}
	}
	
}