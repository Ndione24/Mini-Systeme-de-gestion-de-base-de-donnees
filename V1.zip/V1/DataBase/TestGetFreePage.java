package DataBase;

import java.util.ArrayList;

public class TestGetFreePage {
	
	public static void main(String args[]) 
	{
		ArrayList<String> typecolonne=new ArrayList<>();
		typecolonne.add("int");
		typecolonne.add("string3");
		typecolonne.add("int");
		//RelDef rf=new RelDef(, 3 ,typecolonne);
		//System.out.println(rf.getSlotCount());
		DBManager.getInstance().cleanCommand();
		ArrayList<String> value=new ArrayList<String>();
		value.add("2");
		value.add("abc");
		value.add("3");
		
		ArrayList<String> value1=new ArrayList<String>();
		value1.add("3");
		value1.add("abg");
		value1.add("9");
		DBManager.getInstance().createRelation("ndione", 3, typecolonne);
		DBManager.getInstance().insertCommand("ndione", value);
		DBManager.getInstance().insertCommand("ndione", value1);
		
		//contenu headerPage depuis le
	/*	byte headerpage[];
		PageId hp=new PageId(0, 0);
		DiskManager.getInstance().readPage(hp, headerpage);*/
		
	} 

}
