package DataBase;
import java.util.*;
public class BufferManager {
	
	
	private BufferManager() 
	{
		//bufferPool s'agit de la structure qui contient les Frames(2 frames (cases) dans notre cas ) 
		ArrayList<Frame> bufferPool = new ArrayList<>(Constants.PAGESIZE);
	}
	
	private static BufferManager INSTANCE = new BufferManager ();
	
	
	public static BufferManager getInstance() 
	{
		return INSTANCE ;
	}
	
	ArrayList<Frame> bufferPool = new ArrayList<>(Constants.PAGESIZE);
	int nbCaseLibre=2;

	
	
	/*
	 * @description : 
	 * @param: Une pageId 
	 * @return: Contenu de la pageId
	 * */
	/*public byte[] GetPage(PageId page) 
	{
		
		if (bufferPool.isEmpty())
	} */
	
	
	public void freePage (PageId page, byte valdirty) 
	{
		
	}
	
	
	
	/**
	 * @description: vide completement toutes les cases: met les flag dirty � 1 et les pint_count � 0  
	 */
	public void flushAll() 
	{
		
	}
}
