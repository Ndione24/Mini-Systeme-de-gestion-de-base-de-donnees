package DataBase;

import java.io.IOException;

public class EcrirePage {

	public static void main(String agrs[]) throws IOException 
	{
		
		DiskManager dm= DiskManager.getInstance();
		System.out.println("Creation de fichier");
		
		/*dm.createFile(7);
		
		PageId firstPage= dm.addPage(7);
		PageId twPage= dm.addPage(7);
		PageId thPage= dm.addPage(7); */
		
		System.out.println("Nombre De page ajout� dans le fichier d'indice 7");
		dm.displayNumberPage(7); 
		
		System.out.println("Ecriture sur la page 1 du fichier d'indice 7 ");
		byte bufWrite[]=new byte[Constants.TAILLEBUFFER];
		byte buffRead[]=new byte[Constants.TAILLEBUFFER];
		byte [] buffWritep2=new byte[Constants.TAILLEBUFFER];
		
		
		PageId firstPage= new PageId(7,0);
		PageId page3=new PageId(7,2);
		PageId page2=new PageId(7,1);
		
		
		for(byte i=0;i<10;i++) 
		{
			bufWrite[i]=(byte)(i+1);
		}
		dm.writePage(firstPage, bufWrite);
		
		for(byte i=0;i<10;i++) 
		{
			buffWritep2[i]=(byte) (2*(i+1));
		}
		
		dm.writePage(page3,buffWritep2); 
		 
		
	}
}
