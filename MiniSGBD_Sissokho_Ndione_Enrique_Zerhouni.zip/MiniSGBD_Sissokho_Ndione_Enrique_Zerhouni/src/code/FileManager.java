package code;

import java.util.ArrayList;

public class FileManager {

	private ArrayList<HeapFile> heapFiles;

	private FileManager() {
		this.heapFiles = new ArrayList<HeapFile>();
	}

	/** Instance unique pr�-initialis�e */
	private static FileManager INSTANCE = new FileManager();

	/** Point d'acc�s pour l'instance unique du singleton */

	public static FileManager getInstance() {
		return INSTANCE;
	}

	public void addHeapFile(HeapFile hp) {
		this.heapFiles.add(hp);
	}

	public void init() {
		for (int i = 0; i < DBDef.getINSTANCE().listeRelDef.size(); i++) {
			HeapFile hp = new HeapFile(DBDef.getINSTANCE().listeRelDef.get(i));
			this.heapFiles.add(hp);
		}
	}

	public ArrayList<HeapFile> getAllHeapFile() {
		ArrayList<HeapFile> ah = new ArrayList<>();
		for (HeapFile key : this.heapFiles) {
			ah.add(key);
		}
		return ah;
	}

	/**
	 * 
	 * @param relDef
	 */
	public void CreateRelationFile(RelDef relDef) {
		// cr�er un nouvel objet de type HeapFile et lui attribuer relDef
		HeapFile hp = new HeapFile(relDef);

		// le rajouter � la liste heapFiles
		this.addHeapFile(hp);

		// puis appeler sur cet objet la m�thode createNewOnDisk.

		hp.createNewOnDisk();
	}

	/*
	 * @param record la relation a inserer
	 * 
	 * @param relName le nom correspondant au record a inserer la methode insert une
	 * relation dans un record
	 * 
	 */
	public Rid InsertRecordInRelation(Record record, String relName) {
		for (int i = 0; i < this.heapFiles.size(); i++) {
			if (this.heapFiles.get(i).nomRelation().equals(relName)) {
				return this.heapFiles.get(i).insertRecord(record);
			}
		}
		return null;

	}

	public ArrayList<Record> SelectAllFromRelation(String relName) {
		// on parcours HeapFiles pour selectionner le record de nom RelName

		for (int i = 0; i < this.heapFiles.size(); i++) {
			if (this.heapFiles.get(i).nomRelation().equals(relName)) {
				return this.heapFiles.get(i).getAllRecords();

			}

		}

		System.out.println("can not find relation");
		return null;

	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Record> SelectFromRelation(String relName, int idxCol, String valeur) {

		ArrayList<Record> listeDeRecordsSelectionner = new ArrayList<>();
		//boolean cherche = false;

		// on verifie si la relation extiste
		for (int i = 0; i < this.heapFiles.size(); i++) {
			if (this.heapFiles.get(i).nomRelation().equals(relName)) {

				// si la valeur du record � la colonne idxCol est �gal � valeur, on l'insere
				// � la liste qu'on doit retourner

				// listDeRecords=>la liste de record correspondant au nom de relation pass� en
				// parametre
				ArrayList<Record> listDeRecords = this.heapFiles.get(i).getAllRecords();

				for (int j = 0; j < listDeRecords.size(); j++) {
					if (listDeRecords.get(j).getValues().get(idxCol - 1).equals(valeur)) {
						listeDeRecordsSelectionner.add(listDeRecords.get(j));
					}
				}

			}

		}

		return listeDeRecordsSelectionner;

	}

	/**
	 * on vide la liste de heapFile
	 */
	public void reset() {
		this.heapFiles.clear();
	}

}
