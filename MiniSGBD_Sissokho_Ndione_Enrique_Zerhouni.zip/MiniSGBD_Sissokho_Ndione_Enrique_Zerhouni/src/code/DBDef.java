package code;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class DBDef implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1296361507351248870L;
	private int compteur = 0;
	public ArrayList<RelDef> listeRelDef;

	private static final DBDef INSTANCE = new DBDef();

	private DBDef(ArrayList<RelDef> listeRelDef, int compteur) {
		this.listeRelDef = new ArrayList<RelDef>();
		this.compteur = compteur;

	}

	/**
	 * Constructeur sans argument qui initialise les attributs
	 */
	private DBDef() {
		listeRelDef = new ArrayList<RelDef>();
		compteur = 0;
	}

	/**
	 * <i>L'acc�s � l'unique Instance Instance de la classe</i>
	 * 
	 * @return <i>Unique instance</i>
	 */
	public static DBDef getINSTANCE() {

		return INSTANCE;
	}

	public void init() {

		try {

			File catalog = new File(Constants.CHEMINDB + "Catalog.def");
			
			if (catalog.length() == 0) {
				// aucune raison de continuer
				return;
			}

			FileInputStream fistream = new FileInputStream(catalog);
			ObjectInputStream oistream = new ObjectInputStream(fistream);
			/*
			 * on ecrit maintenant le contenu du fichier catalog.def dans l'instance de
			 * DBdef
			 */
			DBDef dbdef = getINSTANCE();
			dbdef = (DBDef) oistream.readObject();

			/*
			 * on met � jour de l'objet actuel par celui du fichier
			 */
			if (!dbdef.listeRelDef.isEmpty()) {
				setListeRelDef(dbdef.getListeRelDef());
				setCompteur(dbdef.getCompteur());
			}
			oistream.close();
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Erreur survenue �");

		}

	}

	public void finish() {
		
		File catalog=new File(Constants.CHEMINDB + "Catalog.def");
		// cree le fichier si celui l� n'existe pas
		try {
			catalog.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("erreur catalog finish dbdef");
		}
		FileOutputStream fostream;
		ObjectOutputStream oostream;
		// on verifie l'existence des relations
		if (this.listeRelDef.size() > 0) {
			try {
				// creation du fichier dans le dossier specifi�
				fostream = new FileOutputStream(catalog);
				// ecriture de l'objet dans le fichier catalog
				oostream = new ObjectOutputStream(fostream);
				oostream.writeObject(getINSTANCE());
				// maintenant on ferme le flux
				oostream.close();
			} catch (FileNotFoundException e) {

				System.out.println("Le fichier n'a pas �t� trouv� " + e.getMessage());
			} catch (IOException e) {

				System.out.println("Erreur Catalog.def " + e.getMessage());
				e.printStackTrace();
			}
		}
	}

	
	/**
	 * Cette metode ajoute la relation rel dans la liste si elle la contient pas
	 * d'abord
	 * 
	 * @param rel : la nouvelle relation � ajouter
	 */
	public void addRelation(RelDef rel) {
		if (!listeRelDef.contains(rel)) {
			listeRelDef.add(rel);
			compteur++;
			System.out.println("Votre relation a �t� bien ajout�e ");

		} else {
			System.out.println("La liste contient d�j� cette relation");
		}

	}

	public String toString() {

		return this.listeRelDef.toString();
	}

	public void listRelation() {
		System.out.println("Voici la liste des relations");
		for (int i = 0; i < this.listeRelDef.size(); i++) {
			System.out.println(this.listeRelDef.get(i));
		}
	}

	public int getCompteur() {
		return this.compteur;
	}

	public void setCompteur(int compteur) {
		this.compteur = compteur;
	}

	public void setListeRelDef(ArrayList<RelDef> listeRelDef) {
		this.listeRelDef = listeRelDef;
	}

	public ArrayList<RelDef> getListeRelDef() {
		return this.listeRelDef;
	}

	/**
	 * on remet le compteur � 0 et on vide la liste de RelDef
	 */
	public void reset() {
		this.compteur = 0;
		this.listeRelDef.clear();
	}

}