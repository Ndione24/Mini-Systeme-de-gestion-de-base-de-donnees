package code;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;

public class TestRecord {
	
	public static void main(String args[]) 
	{
		ArrayList<String> typecolonne=new ArrayList<>();
		typecolonne.add("int");
		typecolonne.add("string3");
		typecolonne.add("int");
		RelDef rf=new RelDef("ndione", 3 ,typecolonne);
		Record rd= new Record(rf);
		rd.addValue("1");
		rd.addValue("abc");
		rd.addValue("7");
		/*rd.addValue("2");
		rd.addValue("xhs");
		rd.addValue("6");
		rd.addValue("5");
		rd.addValue("acb");
		rd.addValue("4"); */
		
		
		
		byte[] bt=new byte [60];
		byte [] btt= new byte[60];
		ByteBuffer bbb= ByteBuffer.wrap(btt);
		ByteBuffer bb= ByteBuffer.wrap(bt);
		bb.putInt(5);
		//bb.putInt(7);
		bb.putChar('a');
		bb.putChar('c');
		bb.putChar('b');
		bb.putInt(4);
		//bb.putInt(5);
		//bb.putInt(7);
		bb.putChar('a');
		bb.putChar('c');
		bb.putChar('b');
		bb.putInt(4);
		//System.out.println(bb.position());
		bb.rewind();
		
		//System.out.println(Arrays.toString(bt));
		
		rd.readFromBuffer(bb, 0);
		
		rd.dispalayValue();
		
		/*rd.writeToBuffer(btt, 0);
		System.out.println("itll");
		//System.out.println(bbb.getFloat(1));
		
		for(int i=0;i<bbb.capacity();i++)
		{
		
			System.out.print(bbb.get());
			
		}*/
		//System.out.println(Arrays.toString(bbb));
		
	}
}
