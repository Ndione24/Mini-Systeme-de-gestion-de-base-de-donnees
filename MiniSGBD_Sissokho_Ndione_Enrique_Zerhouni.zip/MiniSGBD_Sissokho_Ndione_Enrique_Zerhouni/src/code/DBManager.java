package code;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class DBManager {
	/**
	 * Instance pour creer une instance unique de la classe DBManager
	 */
	private static final DBManager INSTANCE = new DBManager();

	public static final DBManager getInstance() {
		return INSTANCE;
	}

	public void init() {
		// Appel � la methode init de la classe DBDef
		DBDef.getINSTANCE().init();
		FileManager.getInstance().init();

	}

	/**
	 * @description : s'occupe du m�nage
	 */
	public void finish() {
		// Appel � la m�thode finish() de la classe DBDef
		DBDef.getINSTANCE().finish();
		BufferManager.getInstance().FlushAll();
	}

	/**
	 * 
	 * @param cmde
	 * @throws IOException
	 */
	public void processCommand(String cmde) {
		// decoupage de la ligne de commande en plusieurs mots
		StringTokenizer st = new StringTokenizer(cmde);
		int nbArgs = 0;

		// création d'une liste dans laquelle sera stocker les mots decompsés
		List<String> mots = new ArrayList<String>();

		// Boucle de parcours du StringTokenizer
		while (st.hasMoreTokens()) {
			nbArgs++;
			// Ajout du mot dans la liste
			mots.add(st.nextToken());
		}

		// create R 3 int float string8

		// Gestion des mots clés avec switch
		// System.out.println("nb argument "+nbArgs);
		switch (mots.get(0)) {

		case "create":
			// Creation d'une r�lation
			// Maintenant on met les types dans un autre vecteur
			/*
			 * if(nbArgs!=1) { System.out.println("Erreur on argv"); break; }
			 */
			ArrayList<String> lesTypes = new ArrayList<String>();
			for (int i = 3; i < mots.size(); i++) {
				lesTypes.add(mots.get(i));
			}

			createRelation(mots.get(1), Integer.parseInt(mots.get(2)), lesTypes);
			break;
		case "insert":

			ArrayList<String> valeursRecord = new ArrayList<String>();
			for (int i = 2; i < mots.size(); i++) {
				valeursRecord.add(mots.get(i));
				// System.out.println(mots.get(i));

			}
			insertCommand(mots.get(1), valeursRecord);
			break;
		case "insertall":

			insertAllCommand(mots.get(1), mots.get(2));
			break;

		case "clean":
			cleanCommand();
			break;
		case "select":
			int indiceColonne = Integer.parseInt(mots.get(2));
			selectCommand(mots.get(1), indiceColonne, mots.get(3));
			break;
		case "selectall":
			selectAllCommand(mots.get(1));
			break;
		case "delete":
			int indiceColumn = Integer.parseInt(mots.get(2));
			deleteCommand(mots.get(1), indiceColumn, mots.get(3));
			break;
		case "join":
			int indiceCol1=Integer.parseInt(mots.get(3));
			int indiceCol2=Integer.parseInt(mots.get(4));
			joinCommand(mots.get(1), mots.get(2), indiceCol1, indiceCol2);
			break;
		case "":
			System.out.println("Erreur: Saisie incorrecte");
			break;

		default:
			// Affiche le message d'erreur
			System.out.println("Erreur: Saisie incorrecte");
			break;
		}

	}

	/**
	 * Cette methode cree une nouvelle relation et la rajoute � l'instance de DBDef
	 * avce les param�tres pass�s
	 * 
	 * @param nomRelation   : le nom de la relation
	 * @param nbRelation    : le nombre de colonnes
	 * @param typesColonnes : lestype des colonnes
	 */
	public void createRelation(String nomRelation, int nbRelation, List<String> typesColonnes) {

		// Calcul du recordSize
		byte result = 0;

		for (String key : typesColonnes) {

			if (key.toLowerCase().equals("int")) {
				result += 4;

			} else if (key.toLowerCase().equals("float")) {
				result += 4;

			} else if (key.toLowerCase().equals("char")) {
				result += 2;

			} else if (key.substring(0, 6).equals("string")) {
				// on recupere la taille de la chaine
				// c� d le chiffre � la fin du string
				// exple string7 donc 7
				String reste = key.replace("string", "").trim();
				// Mettre 2 octets par caractère
				result += (Integer.parseInt(reste) * 2);

			} else {
				// on pre
				result += 0;
			}
		}

		// le recordSize
		byte recordSize = result;

		// calcul slotCount

		int slotCount = (Constants.PAGESIZE / (recordSize + 1));

		int compteur = DBDef.getINSTANCE().getCompteur();

		RelDef relation = new RelDef(nomRelation, nbRelation, typesColonnes, compteur, recordSize, slotCount);

		// si la relation existe dej�, on sort de la fonction
		for (int i = 0; i < DBDef.getINSTANCE().listeRelDef.size(); i++) {
			if (DBDef.getINSTANCE().listeRelDef.get(i).getNomRelation().equals(nomRelation)) {
				System.out.println("la relation " + relation.getNomRelation() + " existe dej�");
				return;
			}
		}

		DBDef.getINSTANCE().addRelation(relation);

		// Rajoutez un appel � CreateRelationFile dans la m�thode CreateRelation du
		// DBManager.

		FileManager.getInstance().CreateRelationFile(relation);

	}

	public void listerLesRelations() {
		DBDef.getINSTANCE().listRelation();
	}

	public void cleanCommand() {

		// le repertoire DB
		File repertoire = new File(Constants.CHEMINDB);

		// on met tous les fichiers du repertoire DB dans un tableau de fichiers
		File[] lesFichiers = repertoire.listFiles();

		// on supprime tous les fichiers .rf ainsi que le fichier Catatog.def

		for (File key : lesFichiers) {

			if (key.getAbsolutePath().endsWith(".rf") || key.getAbsolutePath().endsWith("Catalog.def")) {
				if (key.delete()) {
					System.out.println(" le fichier " + key + " a �t� bien supprim�");
				} else {
					System.out.println("Error: le fichier " + key + " n'a pas �t� supprim�");
				}
			}
		}
		// System.out.println(Arrays.toString(lesFichiers));

		BufferManager.getInstance().reset();
		FileManager.getInstance().reset();
		DBDef.getINSTANCE().reset();
	}

	/**
	 * la methode doit inserer une relation
	 * 
	 * @param nomRelation : nom de la relation auquel on doit inserer un record
	 * @param values      : les valeures du record � inserer
	 */
	public void insertCommand(String nomRelation, ArrayList<String> values) {
		// on cherche le nom de la relation dans le FileManager
		for (int i = 0; i < FileManager.getInstance().getAllHeapFile().size(); i++) {
			if (FileManager.getInstance().getAllHeapFile().get(i).getRelDef().getNomRelation().equals(nomRelation)) {
				// si le nom de la relation a ete trouv�, on cree un nouveau record et on
				// l'insere

				Record newRecord = new Record(DBDef.getINSTANCE().listeRelDef.get(i), values);

				FileManager.getInstance().getAllHeapFile().get(i).insertRecord(newRecord);
				break;

			}
		}

	}

	public void insertAllCommand(String nomRelation, String nomFichierCsv) {

		// chemin du fichier
		String cheminFileCsv = Constants.CHEMINRACINE + nomFichierCsv;

		String ligne = null;

		try {
			BufferedReader br = new BufferedReader(new FileReader(cheminFileCsv));

			// ligne est une chaine de caratere correspondant � une ligne( un record) du
			// fichier CSV
			while ((ligne = br.readLine()) != null) {
				ArrayList<String> values = new ArrayList<>();
				// les valeurs du record sont separ� par une virgule
				StringTokenizer st = new StringTokenizer(ligne, ",");
				while (st.hasMoreTokens()) {
					values.add(st.nextToken());
				}
				insertCommand(nomRelation, values);

			}
			br.close();

		} catch (FileNotFoundException e) {
			System.out.println("chemin non trouv�");
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectAllCommand(String nomRelation) {
		String nomRelationLowerCase = nomRelation.toLowerCase();
		/*
		 * System.out.println("nom rel "+nomRelationLowerCase);
		 * System.out.println("Size FIleMAnager "+FileManager.getInstance().
		 * getAllHeapFile().size());
		 */
		// on cherche le nom de la relation dans le FileManager
		for (int i = 0; i < FileManager.getInstance().getAllHeapFile().size(); i++) {
			if (FileManager.getInstance().getAllHeapFile().get(i).getRelDef().getNomRelation().toLowerCase()
					.equals(nomRelationLowerCase)) {
				// System.out.println("Oui c'est egaux");
				// on recupere la liste de record associ�e � cette relation
				List<Record> listDeRecords = FileManager.getInstance().getAllHeapFile().get(i).getAllRecords();

				// on affiche maintenant les valeurs des records separ�s par un point virgule

				int nb = 0;
				// System.out.println("taille liste record "+listDeRecords.size());
				for (Record item : listDeRecords) {
					String ligneRecord = "";
					for (int j = 0; j < item.getValues().size(); j++) {
						if (j == (item.getValues().size() - 1)) {
							// pour eviter d'avoir un point virgule � la fin du record
							ligneRecord = ligneRecord + item.getValues().get(j);
						} else {
							ligneRecord = ligneRecord + item.getValues().get(j) + ";";
						}
					}

					System.out.println("record n�" + (nb + 1) + " " + ligneRecord);
					nb++;
				}

				System.out.println("Total records = " + nb);

			}
		}

	}

	public void selectCommand(String nomRelation, int indiceColonne, String valeur) {
		// on recupere la liste des records selectionn�s
		ArrayList<Record> recordSelectione = FileManager.getInstance().SelectFromRelation(nomRelation, indiceColonne,
				valeur);

		int nb = 0;
		for (Record item : recordSelectione) {
			String ligneRecord = "";
			for (int j = 0; j < item.getValues().size(); j++) {
				if (j == (item.getValues().size() - 1)) {
					// pour eviter d'avoir un point virgule � la fin du record
					ligneRecord = ligneRecord + item.getValues().get(j);
				} else {
					ligneRecord = ligneRecord + item.getValues().get(j) + ";";
				}
			}

			System.out.println("record n�" + (nb + 1) + " " + ligneRecord);
			nb++;
		}

		System.out.println("Total records = " + nb);
	}

	public int tailleRecordAtcolumn(RelDef rel, int indiceColumn) {

		int result = 0;

		for (int i = 0; i < indiceColumn; i++) {

			if (rel.getTypesColonnes().get(i).equals("int")) {
				result += 4;

			} else if (rel.getTypesColonnes().get(i).equals("float")) {
				result += 4;

			} else if (rel.getTypesColonnes().get(i).equals("char")) {
				result += 2;

			} else if (rel.getTypesColonnes().get(i).substring(0, 6).equals("string")) {

				String reste = rel.getTypesColonnes().get(i).replace("string", "").trim();
				// Mettre 2 octets par caractère
				result += (Integer.parseInt(reste) * 2);

			} else {

				result += 0;
			}

		}
		return result;
	}

	public void deleteCommand(String nomRelation, int indiceColonne, String valeur) {

		indiceColonne = indiceColonne - 1;
		int tailleAv;
		int total_deleted = 0;
		// ArrayList<Record> recordsToDelete =
		// FileManager.getInstance().SelectFromRelation(nomRelation,
		// indiceColonne,valeur);

		// on met � 0 leur bitMap
		// recuperer la page ou se trouve le record
		// chercher la position du record
		// changer sa bitmap

		// int test=Integer.parseInt(valeur);
		for (int i = 0; i < DBDef.getINSTANCE().listeRelDef.size(); i++) {
			if (DBDef.getINSTANCE().listeRelDef.get(i).getNomRelation().equals(nomRelation)) {
				RelDef relationMatching = DBDef.getINSTANCE().listeRelDef.get(i);

				int pageIndex ;
				String typePourLindice = relationMatching.getTypesColonnes().get(indiceColonne);

				// System.out.println("sizerecord " + relationMatching.getRecordSize());
				int nbSlots = relationMatching.getSlotCount();
				// System.out.println("nbSlot " + nbSlots);
				byte sizeRecord = relationMatching.getRecordSize();
				// headerPage
				int indiceRelation = relationMatching.getFileIdx();
				PageId headerPage = new PageId(indiceRelation, 0);
				byte[] bufferHeaderPage = BufferManager.getInstance().getPage(headerPage);

				ByteBuffer bhp = ByteBuffer.wrap(bufferHeaderPage);
				int nbPage = bhp.getInt(0);
				// System.out.println("HeaderPageee " + bhp.getInt(1));
				BufferManager.getInstance().freePage(headerPage, 0);
				if (nbPage == 0) {
					System.out.println("Erreur in Delete Commande: nombre de Page egale � 0");
					BufferManager.getInstance().freePage(headerPage, 0);
					return;
				}

				for (int j = 1; j <= nbPage; j++) {
					PageId unePage = new PageId(indiceRelation, j);
					byte[] buff = BufferManager.getInstance().getPage(unePage);
					ByteBuffer bb = ByteBuffer.wrap(buff);
					// System.out.println("buffPage " + j + Arrays.toString(buff));
					// la position du record
					// buff[position]=0;
					for (int s = 0; s < nbSlots; s++) {

						if (buff[s] == (byte) 1) {
							bb.position(0);
							int pos = (nbSlots) + (s * sizeRecord);
							bb.position(pos);
							// System.out.println("type " + typePourLindice);

							switch (typePourLindice) {
							case "int":
								tailleAv = tailleRecordAtcolumn(relationMatching, indiceColonne);
								bb.position(pos + tailleAv);
								// System.out.println("taille avant "+tailleAv);
								// System.out.println("position "+indiceColonne);
								int zap = bb.getInt();
								// System.out.println("zap" +zap);
								if (Integer.toString(zap).equals(valeur)) {
									total_deleted++;
									buff[s] = 0;
									BufferManager.getInstance().freePage(unePage, 1);
									//System.out.println("buffPage REm " + j + Arrays.toString(buff));
									// incrementer le nbre de slot libre de la page correspondante
									pageIndex=j*4;
									byte[] bufferHp = BufferManager.getInstance().getPage(headerPage);
									ByteBuffer bh = ByteBuffer.wrap(bufferHp);
									int slotMatching = bh.getInt(pageIndex);
									slotMatching++;
									bh.putInt(pageIndex, slotMatching);
									//System.out.println("headerIncre " + bh.getInt(pageIndex));
									BufferManager.getInstance().freePage(headerPage, 1);

								}
								break;
							case "float":
								tailleAv = tailleRecordAtcolumn(relationMatching, indiceColonne);
								bb.position(pos + tailleAv);
								float match = bb.getFloat();
								if (Float.toString(match).equals(valeur)) {
									total_deleted++;
									buff[s] = 0;
									BufferManager.getInstance().freePage(unePage, 1);
									//System.out.println("buffPage REm " + j + Arrays.toString(buff));
									// incrementer le nbre de slot libre de la page correspondante
									byte[] bufferHp = BufferManager.getInstance().getPage(headerPage);
									pageIndex=j*4;
									ByteBuffer bh = ByteBuffer.wrap(bufferHp);
									int slotMatching = bh.getInt(pageIndex);
									slotMatching++;
									bh.putInt(pageIndex, slotMatching);
									//System.out.println("headerIncre " + bh.getInt(pageIndex));
									BufferManager.getInstance().freePage(headerPage, 1);

								}
								break;
							default:
								// BufferManager2.getInstance().freePage(unePage, 1);

								String reste = typePourLindice.replace("string", "").trim();

								StringBuilder sb = new StringBuilder();

								// lire � partir de position
								tailleAv = tailleRecordAtcolumn(relationMatching, indiceColonne);
								int lenght = Integer.parseInt(reste);
								pos = nbSlots + tailleAv + (s * sizeRecord);

								bb.position(pos);
								for (int x = 0; x < lenght; x++) {
									sb.append(bb.getChar());

								}
								if (sb.toString().toLowerCase().equals(valeur.toLowerCase())) {
									total_deleted++;
									buff[s] = 0;
									//System.out.println("buffPage REm " + j + Arrays.toString(buff));
									BufferManager.getInstance().freePage(unePage, 1);
									// incrementer le nbre de slot libre de la page correspondante
									byte[] bufferHp = BufferManager.getInstance().getPage(headerPage);
									ByteBuffer bh = ByteBuffer.wrap(bufferHp);
									pageIndex=j*4;
									int slotMatching = bh.getInt(pageIndex);
									slotMatching++;
									bh.putInt(pageIndex, slotMatching);
									//System.out.println("headerIncre " + bh.getInt(pageIndex));
									BufferManager.getInstance().freePage(headerPage, 1);
								}
								break;
							}

						}
					}
					BufferManager.getInstance().freePage(unePage, 1);

				}
			} 


		}
		System.out.println("total records supprim� :" + total_deleted);


	} // end

	
	public RelDef searchRelation(String relName) 
	{
		for (int i = 0; i < DBDef.getINSTANCE().listeRelDef.size(); i++) {
			if (DBDef.getINSTANCE().listeRelDef.get(i).getNomRelation().equals(relName)) {
				RelDef relationMatching = DBDef.getINSTANCE().listeRelDef.get(i);
				return relationMatching;
			}
		}
		return null;
	}
	
	public int getNbPageRelation(String relName) 
	{
		RelDef matchingRelname=searchRelation(relName);
		if (matchingRelname==null) 
		{
			System.out.println("Error: can not find relation");
			return 0;
			
		}
		int indiceFileIdx=matchingRelname.getFileIdx();
		//hp=>headerPage
		PageId hp=new PageId(indiceFileIdx,0);
		byte [] buff=BufferManager.getInstance().getPage(hp);
		ByteBuffer b1=ByteBuffer.wrap(buff);
		int nbPage=b1.getInt(0);
		BufferManager.getInstance().freePage(hp, 0);
		return nbPage;
	}
	
	public void joinCommand(String relName1, String relName2,int indiceCol1,int indiceCol2) {
		//Page Nested Loop Join
		RelDef matchingRelname1=searchRelation(relName1);
		RelDef matchingRelname2=searchRelation(relName2);
		//cf indice des tableaux
		indiceCol1=indiceCol1-1;
		indiceCol2=indiceCol2-1;
		
		ArrayList<ArrayList<String>> result=new ArrayList<>();
		
		if(matchingRelname1==null || matchingRelname2==null) 
		{
			RelDef relNull=matchingRelname1==null?matchingRelname1:matchingRelname2;
			System.out.println("Error: can not find relation "+relNull.getNomRelation());
			return;
		}
		
		int nbPage1=getNbPageRelation(relName1);
		int nbPage2=getNbPageRelation(relName2);
		
		if(nbPage1==0) 
		{
			System.out.println("aucune page trouv�e dans 1 ");
			return;
		}
		
		if(nbPage2==0) 
		{
			System.out.println("aucune page trouv�e dans 2 ");
			return;
		}
		
		int totalJoin=0;
		HeapFile hf1= new HeapFile(matchingRelname1);
		HeapFile hf2= new HeapFile(matchingRelname2);
		System.out.println("calcul en cours ...");
		//p1
		for(int i=1;i<=nbPage1;i++) 
		{
			PageId p1=new PageId(matchingRelname1.getFileIdx(),i);
			//p2
			for(int j=1;j<=nbPage2;j++) 
			{
				PageId p2=new PageId(matchingRelname2.getFileIdx(),j);	
				//record de p1
				for(int k=0;k<hf1.getRecordsInDataPage(p1).size();k++)
				{
					
					Record rec1=hf1.getRecordsInDataPage(p1).get(k);
					//record de p2
					for(int l=0;l<hf2.getRecordsInDataPage(p2).size();l++) 
					{
						Record rec2=hf2.getRecordsInDataPage(p2).get(l);
					
						if(rec1.getValues().get(indiceCol1).trim().equals(rec2.getValues().get(indiceCol2).trim())) 
						{
							
							totalJoin++;
							
							ArrayList<String> inter=new ArrayList<>();
							inter.addAll(rec1.getValues());
							inter.addAll(rec2.getValues());
							//rec1.getValues().addAll(rec2.getValues());
							result.add(inter);
							
							/*rec1.getValues().clear();
							rec2.getValues().clear(); */
							
							//System.out.println("yes ");
							//liste addall pour l'affichage
							
						}
					}
				}
			}
		}
		
		//display result
		int nb = 0;
		for (ArrayList<String> item : result) {
			String ligneRecord = "";
			for (int p = 0; p < item.size(); p++) {
				if (p == (item.size() - 1)) {
					// pour eviter d'avoir un point virgule � la fin du record
					ligneRecord = ligneRecord + item.get(p);
				} else {
					ligneRecord = ligneRecord + item.get(p) + ";";
				}
			}

			System.out.println("record n�" + (nb + 1) + " " + ligneRecord);
			nb++;
		}

		System.out.println("total join :"+totalJoin);
	}

}