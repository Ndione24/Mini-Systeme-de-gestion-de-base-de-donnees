package DataBase;
import java.io.*;
public class TestRandomAccess {
	public static void main(String [] args ) {
		
			   
		
		   
		      try {
		         String s = "Hello World";
		         String a = "Helloooooooo Worlddddddd";
		         
		         // create a new RandomAccessFile with filename test
		         //File unTest= new File("test.txt");
		 RandomAccessFile raf = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\Code\\Texte.txt", "rw");
		         

		         
		       //ecriture carrartere par carractere  
		         // write a char in the file
		         raf.writeChars(s);

		         // set the file pointer at 0 position
		         raf.seek(0);

		         // read chars
		         for (int i = 0; i < 11; i++) {
		            System.out.print("" + raf.readChar());
		         }

		         // set the file pointer at 0 position
		         //raf.seek(0);

		         // change the line for better view 	
		         System.out.println();
		         
		         
		         
		         
		         
		         // method writes a string to the file using modified UTF-8 encoding in a machine-independent manner.
		         raf.writeUTF(a);
		         
		       //set the file pointer at the end position
		         long lenght= raf.length();
		         raf.seek(lenght+1);
		         
		         String alpha="Nous voullons la victoire ";
		         raf.writeUTF(alpha);
		         
		         // read string
		         System.out.println("" + raf.length());
		         
		         
		      } catch (IOException ex) {
		         ex.printStackTrace();
		      }
		
			
	}
}
