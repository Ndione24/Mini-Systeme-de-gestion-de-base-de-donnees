package DataBase;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class DBManager {
	/**
	 * Instance pour creer une instance unique de la classe DBManager
	 */
	private static final DBManager INSTANCE = new DBManager () ;


	
	 public static final DBManager getInstance() 
	    {
	        return INSTANCE;
	    }

	

	public void init() {
		// Appel � la methode init de la classe DBDef
		DBDef.getINSTANCE().init();

	}

	/**
	 * @description : s'occupe du m�nage
	 */
	public void finish() {
		// Appel � la m�thode finish() de la classe DBDef
		DBDef.getINSTANCE().finish();
	}
	


	/**
	 * 
	 * @param cmde
	 * @throws IOException 
	 */
	public void processCommand(String cmde) {
		// decoupage de la ligne de commande en plusieurs mots
		StringTokenizer st = new StringTokenizer(cmde);

		// création d'une liste dans laquelle sera stocker les mots decompsés
		List<String> mots = new ArrayList<String>();

		// Boucle de parcours du StringTokenizer
		while (st.hasMoreTokens()) {

			// Ajout du mot dans la liste
			mots.add(st.nextToken());
		}
		
		//create R 3 int float string8
		
		// Gestion des mots clés avec switch
		switch (mots.get(0)) {

		case "create":
			// Creation d'une r�lation
			// Maintenant on met les types dans un autre vecteur
			ArrayList<String> lesTypes = new ArrayList<String>();
			for (int i = 3; i < mots.size(); i++) {
				lesTypes.add(mots.get(i));
			}

			createRelation(mots.get(1), Integer.parseInt(mots.get(2)), lesTypes);
			break;
		case "insert":
			ArrayList<String> valeursRecord = new ArrayList<String>();
			for (int i = 2; i < mots.size(); i++) {
				valeursRecord.add(mots.get(i));
				//System.out.println(mots.get(i));

			}
			insertCommand(mots.get(1), valeursRecord);
			break;
		case "insertAll":

			insertAllCommand(mots.get(1), mots.get(2));
			break;

		case "clean":
			cleanCommand();
			break;
		case "select":
			int indiceColonne = Integer.parseInt(mots.get(2));
			selectCommand(mots.get(1), indiceColonne, mots.get(3));
			break;
		case "selectAll":
			selectAllCommand(mots.get(1));
			break;

		default:
			// Affiche le message d'erreur
			System.out.println("Erreur: Saisie incorrecte");
			break;
		}

	}

	/**
	 * Cette methode cree une nouvelle relation et la rajoute � l'instance de DBDef
	 * avce les param�tres pass�s
	 * 
	 * @param nomRelation   : le nom de la relation
	 * @param nbRelation    : le nombre de colonnes
	 * @param typesColonnes : lestype des colonnes
	 */
	public void createRelation(String nomRelation, int nbRelation, List<String> typesColonnes) {
		
		
			//Calcul du recordSize
			byte result=0;
			
			for(String key: typesColonnes) 
			{
		
				
				if(key.toLowerCase().equals("int"))
				{
					result+=4;
					
				}
				else if(key.toLowerCase().equals("float")) 
				{
					result+=4;
					
					
				}
				else if(key.toLowerCase().equals("char")) 
				{
					result+=2;
					
					
				}
				else if(key.substring(0,6).equals("string")) 
				{
					// on recupere la taille de la chaine
					// c� d le chiffre �  la fin du string
					// exple string7 donc 7
					String reste = key.replace("string", "").trim();
					// Mettre 2 octets par caractère
					result += (Integer.parseInt(reste) * 2);																																	
					
				}
				else 
				{
					//on pre
					result+=0;
				}
			}
			
			// le recordSize
		byte recordSize=result;
		
		//calcul slotCount
		
		int slotCount=(Constants.PAGESIZE/(recordSize+1));
		
		
		int compteur=DBDef.getINSTANCE().getCompteur();
		
		
		
		RelDef relation = new RelDef(nomRelation, nbRelation,typesColonnes,compteur,recordSize,slotCount);
		
		DBDef.getINSTANCE().addRelation(relation);
		
		System.out.println();
		
		
		//Rajoutez un appel � CreateRelationFile dans la m�thode CreateRelation du DBManager.
		
		FileManager.getInstance().CreateRelationFile(relation);
		
	}
	
	public void listerLesRelations()
	{
		DBDef.getINSTANCE().listRelation();
	}
	
	public void cleanCommand() 
	{
		
		//le repertoire DB
		File repertoire= new File(Constants.CHEMINDB);
		
		//on met tous les fichiers du repertoire DB dans un tableau de fichiers 
		File[] lesFichiers=repertoire.listFiles();
		
		
		//on supprime tous les fichiers .rf ainsi que le fichier Catatog.def
		
		for(File key : lesFichiers)
		{
			
			if(key.getAbsolutePath().endsWith(".rf") || key.getAbsolutePath().endsWith("Catalog.def")) {
				if(key.delete())
				{
					System.out.println(" le fichier "+ key+ " a �t� bien supprim�");
				}
				else 
				{
					System.out.println("Error: le fichier "+ key+ " n'a pas �t� supprim�");
				}
		    }
		}
		//System.out.println(Arrays.toString(lesFichiers));
		
		
		BufferManager2.getInstance().reset();
		FileManager.getInstance().reset();
		DBDef.getINSTANCE().reset();
	}
	
	/**
	 * la methode doit inserer une relation 
	 * @param nomRelation : nom de la relation auquel on doit inserer un record 
	 * @param values : les valeures du record � inserer
	 */
	public void insertCommand(String nomRelation,ArrayList<String> values) 
	{
		String nomRelationLowerCase=nomRelation.toLowerCase();
		
		//on cherche le nom de la relation dans le FileManager 
		for(int i=0;i<FileManager.getInstance().getAllHeapFile().size();i++)
		{
		if(FileManager.getInstance().getAllHeapFile().get(i).getRelDef().getNomRelation().toLowerCase().equals(nomRelationLowerCase)) 
		{
			//si le nom de la relation a ete trouv�, on cree un nouveau record et on l'insere
			Record newRecord= new Record(DBDef.getINSTANCE().listeRelDef.get(i),values);
			
			FileManager.getInstance().getAllHeapFile().get(i).InsertRecord(newRecord);
			break;
			
			
		 }
		}
		
	}
	
	public void insertAllCommand(String nomRelation,String nomFichierCsv) 
	{
	
	
		//chemin du fichier
		String cheminFileCsv=Constants.CHEMINRACINE+nomFichierCsv;
		
		String ligne=null;
		
		
		try {
			BufferedReader br= new BufferedReader(new FileReader (cheminFileCsv));
			
			//ligne est une chaine de caratere correspondant � une ligne( un record) du fichier CSV
			while((ligne=br.readLine())!=null)
			{
				ArrayList<String> values =new ArrayList<>();
				//les valeurs du record sont separ� par une virgule
				StringTokenizer st = new StringTokenizer(ligne,",");
				 while (st.hasMoreTokens()) {  
			         values.add(st.nextToken());
			     }
				 insertCommand(nomRelation,values);
				 
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void selectAllCommand(String nomRelation) 
	{
		String nomRelationLowerCase=nomRelation.toLowerCase();
		//on cherche le nom de la relation dans le FileManager 
		for(int i=0;i<FileManager.getInstance().getAllHeapFile().size();i++)
		{
		if(FileManager.getInstance().getAllHeapFile().get(i).getRelDef().getNomRelation().toLowerCase().equals(nomRelationLowerCase)) 
		{
			//on recupere la liste de record associ�e � cette relation
			List<Record> listDeRecords=FileManager.getInstance().getAllHeapFile().get(i).getAllRecords();
			
			//on affiche maintenant les valeurs des records separ�s par un point virgule
			
			int nb=0;
			for(Record item: listDeRecords) 
			{
				String ligneRecord="";
				for (int j=0;j<item.getValues().size();j++)
				{
					if(j==(item.getValues().size()-1))
					{
						//pour eviter d'avoir un point virgule � la fin du record
						ligneRecord=ligneRecord+item.getValues().get(j);
					}
					else 
					{
						ligneRecord=ligneRecord+item.getValues().get(j)+";";
					}
				}
				
				System.out.println("record n�"+(nb+1)+ " "+ligneRecord);
				nb++;
			}
			
			System.out.println("Total records = "+nb);
			
			}
		}
		
	}
	
	public void selectCommand(String nomRelation,int indiceColonne,String valeur) 
	{
		//on recupere la liste des records selectionn�s
		ArrayList<Record> recordSelectione=FileManager.getInstance().SelectFromRelation(nomRelation, indiceColonne, valeur);
	
		int nb=0;
		for(Record item: recordSelectione) 
		{
			String ligneRecord="";
			for (int j=0;j<item.getValues().size();j++)
			{
				if(j==(item.getValues().size()-1))
				{
					//pour eviter d'avoir un point virgule � la fin du record
					ligneRecord=ligneRecord+item.getValues().get(j);
				}
				else 
				{
					ligneRecord=ligneRecord+item.getValues().get(j)+";";
				}
			}
			
			System.out.println("record n�"+(nb+1)+ " "+ligneRecord);
			nb++;
		}
		
		System.out.println("Total records = "+nb);
	}
	
	
	
}	