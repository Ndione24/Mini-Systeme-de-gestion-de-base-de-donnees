package DataBase;

import java.util.ArrayList;

public class DBDef {

	private int compteur=0;
	public  ArrayList<RelDef> listeRelDef;
	
	private static final DBDef INSTANCE = new DBDef();

	private DBDef(ArrayList<RelDef> listeRelDef, int compteur) {
		this.listeRelDef = new ArrayList<RelDef>();
		this.compteur = compteur;

	}
	

	/**
	 * Constructeur sans argument qui initialise les attributs
	 */
	private DBDef() {
		listeRelDef = new ArrayList<RelDef>();
		compteur = 0;
	}

	/**
	 * <i>L'acc�s � l'unique Instance Instance de la classe</i>
	 * 
	 * @return <i>Unique instance</i>
	 */
	public static DBDef getINSTANCE() {
	
		return INSTANCE;
	}
	
	

	public void init() {
		
			
		
	}

	public void finish() {
	}

	/**
	 * Cette metode ajoute la relation rel dans la liste si elle la contient pas
	 * d'abord
	 * 
	 * @param rel : la nouvelle relation � ajouter
	 */
	public void addRelation(RelDef rel) {
		if (!listeRelDef.contains(rel)) {
			listeRelDef.add(rel);
			compteur++;
			System.out.println("Votre relation a �t� bien ajout�e ");
			
		} else {
			System.out.println("La liste contient d�j� cette relation");
		}

	}
	
	public String toString() {
		
		   return this.listeRelDef.toString();
		}
	
	public void listRelation() 
	{
		System.out.println("Voici la liste des relations");
		for(int i=0;i<this.listeRelDef.size();i++)
		{
			System.out.println(this.listeRelDef.get(i));
		}
	}
	
	public int getCompteur() 
	{
		return this.compteur;
	}
	
	/**
	 * on remet le compteur � 0 et on vide la liste de RelDef
	 */
	public void reset() 
	{
		this.compteur=0;
		this.listeRelDef.clear();
	}
	
}