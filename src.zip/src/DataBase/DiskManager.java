package DataBase;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class DiskManager {

	int fileIdx;
	
	private DiskManager ()
    {
		
    }
	private static DiskManager INSTANCE = new DiskManager();
	
	
	public static  DiskManager getInstance() 
	{
		return INSTANCE ;
	}
	
	
	
	public void  createFile(int fileIdx) {
	try {
	
		// Cr�ation du fichier
		RandomAccessFile file = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\"+ "Data_" + fileIdx + ".rf", "rw");

		System.out.println(file.length());
		// fermeture du fichier
		file.close();
	} catch (FileNotFoundException e) {

		// Affichage du message d'erreur
		System.out.println("Fichier non trouv� " + e.getMessage());
		e.getStackTrace();
	} catch (IOException e) {

		// Affichage du message d'erreur
		System.out.println(e.getMessage());
		e.getStackTrace();
	}
		
	}
	
	
	
	public PageId addPage(int fileIdx) throws IOException 
	{
		RandomAccessFile file = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\" + "Data_" + fileIdx+ ".rf", "rw");
		
		//on se place � la fin de la page 
		file.seek(file.length());
		
		//on ajoute au fichier pageSize octets
		
		System.out.println("taille du fichier avant" +file.length());
		
		file.write(new byte[Constants.PAGESIZE]);
		
		System.out.println("taille du fichier apres ajout " +file.length());
		//l'id de la page cr�e est obtenu en faisant le rapport de la taille du fichier divis� par PAGESIZE
		
		/*int PageIdxNew;
		if (file.length()==0) 
		{
			PageIdxNew=0;
		}
		else 
		{*/
		
		int	PageIdxNew=(int )( (file.length()/Constants.PAGESIZE)-1) ;
		
				
		
		PageId idDelaNouvellePage= new PageId(fileIdx,PageIdxNew);
		
		file.close();
		
		return idDelaNouvellePage;
		
	}
	
	public void readPage (PageId page, byte[] buff)
	{
		try {
		RandomAccessFile file = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\" + "Data_"+ page.getFileIdx()+ ".rf", "r");
		
		//file.seek(0);
		file.seek(page.getPageIdx() * (Constants.PAGESIZE));
		
		file.read(buff);
		
		file.close();
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
	
	public void writePage(PageId page,byte[] buff) 
	{
		try {
			RandomAccessFile file = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\" + "Data_" + page.getFileIdx()+ ".rf", "rw");
			
			
			
			file.seek(page.getPageIdx() * (Constants.PAGESIZE));
			file.write(buff);
			
			file.close();
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	
	
	public  void displayNumberPage(int fileIdx) throws IOException 
	{
	RandomAccessFile file = new RandomAccessFile("C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB\\" + "Data_" +fileIdx+ ".rf", "rw");

		long numberOfpage=file.length()/Constants.PAGESIZE;
		
		System.out.println(numberOfpage);
	}
	
	
	
}





