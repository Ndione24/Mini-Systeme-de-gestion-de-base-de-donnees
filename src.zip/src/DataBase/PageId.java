package DataBase;

public class PageId {
	
	 private int  fileIdx ;
	 private int pageIdx;
	 
	 public PageId( int fileIdx , int pageIdx)
	 {
		 this.fileIdx= fileIdx;
		 this.pageIdx= pageIdx;
	 }

	 
	
		public void setFileIdx(int fileIdx) {
			this.fileIdx = fileIdx;
		}

		public void setPageIdx(int pageIdx) {
			this.pageIdx = pageIdx;
		}
		
		public int getPageIdxCorrespondant(int fileIdx) 
		{
			return this.pageIdx;
		}
		public int getFileIdx() {
			return fileIdx;
		}

		public int getPageIdx() {
			return pageIdx;
		}
		
		
		//equals � ajouter
		/**
		 * <i>R�definition de la m�thode toString de la classe Object</i>
		 * 
		 * @return <i>L'identifiant du fichier et de la pageId</i>
		 */
		public String toString() {
			return " " + fileIdx + " " + pageIdx;
		}
		

		public boolean equals(PageId pageid)
		{
			return this ==pageid;
		}
		
}
