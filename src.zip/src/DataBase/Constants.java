package DataBase;

public class Constants {
	
	  //la taille d'un page
	public static final byte PAGESIZE = 10;
	  //nombre de case =2
	public static final int FRAMECOUNT=2;

	public static String CHEMINDB="C:\\Users\\LENOVO E330\\eclipse-workspace\\ProjetSGBD\\src\\DB";
	
	public static String CHEMINRACINE="";
	
}
