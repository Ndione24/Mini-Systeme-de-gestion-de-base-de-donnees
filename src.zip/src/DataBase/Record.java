package DataBase;

import java.util.List;
import java.util.StringTokenizer;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;

public class Record {
	
	private RelDef relDef;
	
	private List<String> values;
	
	List<String> typesValues = new ArrayList<String>();

	
	public Record (RelDef relDef,List<String> values){
		this.values=values;
		this.relDef=relDef;

	} 

	/**
	 * 2�me constructeur qui initialise les attributs en fonction des variables
	 * pass�s en param�tre
	 */

	

	/**
	 * constructeur qui prend en parametre une reldef
	 */

	public Record(RelDef relDef) {
		this.relDef = relDef;
		//values aura comme taille le nombre de colonne de la relation
		this.values = new ArrayList<String>(relDef.getNbColonnes());
		List<String> typeColonne=relDef.getTypesColonnes();
		
		for (String s : typeColonne ) {
			typesValues.add(s);
		}
		
	}

	/**
	 * Les gettters et setters necessaires
	 */
	public RelDef getRelDef() {
		return this.relDef;
	}

	public void setRelDef(RelDef relDef) {
		this.relDef = relDef;
	}

	public List<String> getValues() {
		return this.values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	/**
	 * methode qui devra �crire les valeurs du Record dans le buffer, l�une apr�s
	 * l�autre, � partir de position.
	 */

	public void writeToBuffer(ByteBuffer buff, int position) {
	
		
		//la taille de values est egale � nombreColonne
		
		typesValues = relDef.getTypesColonnes();
		
		//on met la position du curseur � la position " position " donn�e		
		buff.position(position);
		
			for (int i=0;i<this.values.size();i++) {
			if (typesValues.get(i).equals("int")) {
				
				int interm = Integer.parseInt(values.get(i));
				buff.putInt(interm);
			}
			
			// On verifie si c'est un float
			if (typesValues.get(i).equals("float")) {
				// variable intermediaire pour convertir le type
				// avant de le mettre dans le buffer
				float interm = Float.parseFloat(values.get(i));
				buff.putFloat(interm);
			}
			

			// On verifie si c'est un double
			if (typesValues.get(i).equals("double")) {
				// variable intermediaire pour convertir le type
				// avant de le mettre dans le buffer
				double interm = Double.parseDouble(values.get(i));
				buff.putDouble(interm);
			}
			
			
			
			if (typesValues.get(i).startsWith("string")) {
				String interm = values.get(i);
				//encapsule un tableau de byte dans la memoire
				buff.put(ByteBuffer.wrap(interm.getBytes()));
			}

		} // fin boucle for

	}

	/**
	 * cette methode devra lire les valeurs du Record depuis le buffer, l�une apr�s
	 * l�autre, � partir de position.
	 */

		// rempli les valeurs du records depuis le buffer
	public void readFromBuffer(byte[] buf, int position) {
		
		ByteBuffer buff= ByteBuffer.wrap(buf);
		//on doit retourner un buffer
		buff.position(position);
		int i=position;
		while(i<buff.capacity()) {	
			
			System.out.println(buff.get());
			
			i++;
		}
		

	
	}

}